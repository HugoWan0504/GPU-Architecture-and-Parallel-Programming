#!/bin/bash
# Usage: run.sh [--memcheck | --racecheck | --synccheck] <program> [num_elements [num_bins]]
# Runs ./<program> (histogram-basic or histogram-privatized; its output goes to the log) and turns a failure into an error annotation.
# With a --*check option, runs it under that compute-sanitizer tool.
SANITIZER_RC=99   # distinct from the program's own exit codes (1 = wrong results, 255 = CUDA error)
tool=
case "$1" in
  --memcheck|--racecheck|--synccheck) tool=${1#--}; shift ;;
esac
prog=$1; shift
if [ -n "$tool" ]; then
  limit=300
  # API errors (bad launch config, launch timeout, ...) are left to the program's own CHECK and exit 255
  cmd=(compute-sanitizer --tool $tool --report-api-errors no --error-exitcode $SANITIZER_RC ./$prog)
else
  limit=60
  cmd=(./$prog)
fi
# No commas: they separate the properties of a workflow command, so the title would be cut there
name="$prog input ${1:-1000000} bins ${2:-4096}${tool:+ ($tool)}"
timeout $limit "${cmd[@]}" "$@"
rc=$?
case $rc in
  0)   exit 0 ;;
  1)   msg="Wrong results; the log lists the first wrong bins and the total count" ;;
  124) msg="Timed out after $limit s" ;;
  255) msg="CUDA error; the log shows the message and the line. An error inside the kernel is reported at the cudaDeviceSynchronize() after the launch: an illegal memory access, or 'the launch timed out' if the kernel hangs or runs too long" ;;
  $SANITIZER_RC)
    case $tool in
      memcheck)  msg="Invalid memory access; the compute-sanitizer log shows the kernel, thread and address. Check your bounds checks on the input, and that the private histogram's size and loops cover exactly num_bins" ;;
      racecheck) msg="Shared memory data race; the compute-sanitizer log shows where. Check that every update of the private histogram in shared memory uses atomicAdd" ;;
      synccheck) msg="Invalid __syncthreads(); the compute-sanitizer log shows where. Every thread of the block must reach the same __syncthreads(), so don't put it inside a branch or loop that only some threads take" ;;
    esac ;;
  *)   msg="Crashed with exit code $rc" ;;
esac
# Start on a new line: the program may have died mid-line
echo
echo "::error title=$name failed::$msg"
exit $rc
