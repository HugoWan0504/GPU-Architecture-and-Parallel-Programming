#!/bin/bash
# Usage: run.sh [--memcheck|--racecheck|--synccheck|--initcheck] <m> [k n]
# Runs ./sgemm-tiled (its output goes to the log) and turns a failure into an error annotation.
# With a sanitizer flag, runs it under compute-sanitizer with that tool:
#   memcheck  - out-of-bounds or misaligned global/shared accesses
#   racecheck - shared-memory races (e.g. a missing __syncthreads())
#   synccheck - invalid use of __syncthreads() (e.g. inside a divergent branch)
#   initcheck - reads of uninitialized global memory
SANITIZER_RC=99   # distinct from sgemm-tiled's own exit codes (1 = wrong results/usage, 255 = CUDA error)
tool=""
case "$1" in
  --memcheck|--racecheck|--synccheck|--initcheck) tool="${1#--}"; shift ;;
esac
if [ -n "$tool" ]; then
  limit=600
  # API errors (bad launch config, launch timeout, ...) are left to sgemm-tiled's own CHECK and exit 255
  cmd=(compute-sanitizer --tool "$tool" --report-api-errors no --error-exitcode $SANITIZER_RC ./sgemm-tiled)
else
  limit=120
  cmd=(./sgemm-tiled)
fi
size="${*// / x }"
timeout $limit "${cmd[@]}" "$@"
rc=$?
case $rc in
  0)   exit 0 ;;
  1)   msg="Wrong results; the log lists the first mismatched elements" ;;
  124) msg="Timed out after $limit s" ;;
  255) msg="CUDA error; the log shows the message and the line. An error inside the kernel is reported at the cudaDeviceSynchronize() after the launch: an illegal memory access, or 'the launch timed out' if the kernel hangs or runs too long" ;;
  $SANITIZER_RC)
    case $tool in
      memcheck)  msg="Invalid memory access; the compute-sanitizer log shows the kernel, thread and address. Check your bounds checks for rows, columns and the tile loads" ;;
      racecheck) msg="Shared-memory race; the log shows the conflicting accesses. Check that every shared-memory write is followed by __syncthreads() before it is read, and every read is finished before the tile is overwritten" ;;
      synccheck) msg="Invalid __syncthreads(); do not call it inside a branch that only some threads of the block take (e.g. after an early return for out-of-range threads)" ;;
      initcheck) msg="Uninitialized memory read; the log shows where. Check that C is fully written and that padding in partial tiles is set to 0" ;;
    esac ;;
  *)   msg="Crashed with exit code $rc" ;;
esac
# Start on a new line: the program may have died mid-line
echo
echo "::error title=sgemm-tiled ${tool:+($tool) }$size failed::$msg"
exit $rc
