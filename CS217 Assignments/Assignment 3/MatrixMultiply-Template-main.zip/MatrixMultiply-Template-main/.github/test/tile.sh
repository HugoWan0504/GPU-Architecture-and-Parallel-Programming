#!/bin/bash
# Usage: tile.sh "<make args>" <m> [k n]
# Rebuilds with the given block-size options (e.g. "TILE=8" or "TILE_X=32 TILE_Y=8"), then runs a size
# with run.sh. The Makefile's .tile stamp makes sure the object files are rebuilt for the new options.
args="$1"; shift
echo "Building with: make $args"
if ! make $args; then
  echo "::error title=build with $args failed::The code does not compile with these block-size options"
  exit 2
fi
bash "$(dirname "$0")/run.sh" "$@"
