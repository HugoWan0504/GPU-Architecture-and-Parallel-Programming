# Sourced by setup.sh and run.sh. cuTile needs a GPU of compute capability 8.0 or newer (it has
# no CPU mode). The virtual environment is cached outside the workspace, keyed by the
# requirements, and shared by all repositories on the runner.
_req_hash=$(sha1sum < "$(dirname "${BASH_SOURCE[0]}")/../../requirements.txt" | cut -c1-8)
TILEMM_CACHE="${TILEMM_CACHE:-$HOME/.cache/tilemm-ci}"
TILEMM_VENV="$TILEMM_CACHE/venv-cutile-$_req_hash"
TILEMM_PY="$TILEMM_VENV/bin/python"
# Keep the compile caches in the workspace (deleted by the cleanup job)
_ws="${GITHUB_WORKSPACE:-$PWD}"
export CUDA_TILE_CACHE_DIR="$_ws/.cutile-cache" CUPY_CACHE_DIR="$_ws/.cupy-cache"
# CuPy finds the CUDA toolkit through CUDA_PATH
if [ -z "$CUDA_PATH" ] && [ -d /usr/local/cuda ]; then export CUDA_PATH=/usr/local/cuda; fi
if [ -n "$CUDA_PATH" ]; then export PATH="$CUDA_PATH/bin:$PATH"; fi
