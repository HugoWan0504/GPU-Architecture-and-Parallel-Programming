#!/bin/bash
# Checks the runner's GPU, creates the cached virtual environment with cuTile and CuPy if it
# doesn't exist yet, and prints the versions.
source "$(dirname "$0")/env.sh"
nvidia-smi --query-gpu=index,name,compute_cap --format=csv 2>/dev/null
cc=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1)
if [ -z "$cc" ] || ! awk -v c="$cc" 'BEGIN { exit !(c >= 8.0) }'; then
  echo "::error title=Runner has no suitable GPU::cuTile needs a GPU of compute capability 8.0 or newer (found: ${cc:-none}). This is a problem with the test runner, not your code"
  exit 1
fi

mkdir -p "$TILEMM_CACHE"
exec 9>"$TILEMM_CACHE/lock"
flock 9   # other repositories may be setting up the same environment at the same time
if [ ! -f "$TILEMM_VENV/.ready" ]; then
  py=""
  for cand in python3.13 python3.12 python3.11 python3; do
    p=$(command -v $cand) || continue
    "$p" -c 'import sys, venv, ensurepip; sys.exit(sys.version_info < (3, 11))' 2>/dev/null && { py=$p; break; }
  done
  if [ -z "$py" ]; then
    echo "::error title=No usable Python::The runner needs Python 3.11 or newer with venv"
    exit 1
  fi
  echo "Creating $TILEMM_VENV with $py"
  rm -rf "$TILEMM_VENV"
  "$py" -m venv "$TILEMM_VENV" || exit 1
  pip=("$TILEMM_PY" -m pip install --no-cache-dir -q)
  "${pip[@]}" --upgrade pip || exit 1
  "${pip[@]}" -r requirements.txt || exit 1
  touch "$TILEMM_VENV/.ready"
fi
flock -u 9
"$TILEMM_PY" -c 'import sys, cupy, cuda.tile as ct; print("Python", sys.version.split()[0], "| cuda-tile", ct.__version__, "| cupy", cupy.__version__)'
