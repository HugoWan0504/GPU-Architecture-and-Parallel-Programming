"""Checks tilemm.py: a @ct.kernel that uses ct.load, ct.mma (or ct.matmul), ct.store and zero
padding; a ct.launch; and no matrix product outside the kernel (CuPy's @ or .dot would compute C
without the kernel). Runs with any Python 3; prints GitHub error annotations."""
import ast
import sys

tree = ast.parse(open("tilemm.py").read(), "tilemm.py")
errors = []


def is_kernel(fn):
    return any(isinstance(d, ast.Attribute) and d.attr == "kernel" or
               isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute) and d.func.attr == "kernel"
               for d in fn.decorator_list)


def calls(node):
    return {n.func.attr for n in ast.walk(node)
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}


kernels = [f for f in ast.walk(tree) if isinstance(f, ast.FunctionDef) and is_kernel(f)]
if not kernels:
    errors.append(("No cuTile kernel", "tilemm.py has no @ct.kernel function"))
else:
    used = set().union(*(calls(k) for k in kernels))
    for name in ("load", "store"):
        if name not in used:
            errors.append((f"No ct.{name}", f"The kernel never calls ct.{name}()"))
    if not used & {"mma", "matmul"}:
        errors.append(("No ct.mma", "Multiply the tiles with ct.mma(a, b, acc)"))
    zero = any(isinstance(n, ast.Attribute) and n.attr == "ZERO" for k in kernels for n in ast.walk(k))
    if "load" in used and not zero:
        errors.append(("No zero padding",
                       "Pass padding_mode=ct.PaddingMode.ZERO to ct.load: partial tiles at the edges "
                       "of A and B are otherwise undefined, even if they happen to be zero today"))

kernel_nodes = {id(n) for k in kernels for n in ast.walk(k)}
for n in ast.walk(tree):
    if id(n) in kernel_nodes:
        continue
    if isinstance(n, ast.BinOp) and isinstance(n.op, ast.MatMult):
        errors.append(("Matrix product outside the kernel",
                       f"Line {n.lineno} uses @ outside the kernel; C must be computed by your cuTile kernel"))
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("dot", "matmul", "einsum", "tensordot"):
        errors.append(("Matrix product outside the kernel",
                       f"Line {n.lineno} calls .{n.func.attr}() outside the kernel; C must be computed by your cuTile kernel"))
if "launch" not in calls(tree):
    errors.append(("No ct.launch", "tiled_matmul never launches the kernel with ct.launch()"))

for title, msg in errors:
    print(f"::error title={title}::{msg}")
if not errors:
    print("tilemm.py has a @ct.kernel with ct.load (zero padding), ct.mma and ct.store, launched with ct.launch")
sys.exit(1 if errors else 0)
