#!/bin/bash
# Usage: run.sh [--memcheck] [main.py options] [m | m k n]
# Runs python main.py with the given arguments (its output goes to the log) and turns a failure
# into an error annotation. main.py surrounds A and B with NaN and C with guard values, which
# catch reads and writes past their edges. --memcheck instead allocates the matrices exactly and
# runs under compute-sanitizer.
source "$(dirname "$0")/env.sh"
SANITIZER_RC=99   # distinct from main.py's own exit codes
desc="${*:-(default size)}"
if [ "$1" = --memcheck ]; then
  shift
  limit=600
  export TILEMM_NO_GUARD=1
  cmd=(compute-sanitizer --tool memcheck --report-api-errors no --error-exitcode $SANITIZER_RC "$TILEMM_PY" main.py)
else
  limit=300
  cmd=("$TILEMM_PY" main.py)
fi
timeout $limit "${cmd[@]}" "$@"
rc=$?
case $rc in
  0)   exit 0 ;;
  1)   msg="Wrong results; the log lists the first mismatched elements and a hint" ;;
  2)   msg="Bad arguments to main.py" ;;
  3)   msg="tilemm.py raised an exception; the log shows the traceback (for a compile error, the kernel line it could not compile)" ;;
  4)   msg="No GPU visible on the test runner; this is a problem with the runner, not your code" ;;
  124) msg="Timed out after $limit s" ;;
  $SANITIZER_RC) msg="Invalid memory access; the compute-sanitizer log shows the kernel and address. Check the indices of your loads and stores" ;;
  *)   msg="Crashed with exit code $rc" ;;
esac
# Start on a new line: the program may have died mid-line
echo
echo "::error title=main.py $desc failed::$msg"
exit $rc
