#!/bin/bash
# Usage: run.sh [--memcheck] <m> [n]
# Runs ./mat-add (its output goes to the log) and turns a failure into an error annotation.
# With --memcheck, runs it under compute-sanitizer to catch out-of-bounds accesses.
MEMCHECK_RC=99   # distinct from mat-add's own exit codes (1 = wrong results, 255 = CUDA error)
if [ "$1" = --memcheck ]; then
  shift
  limit=300
  # API errors (bad launch config, launch timeout, ...) are left to mat-add's own CHECK and exit 255
  cmd=(compute-sanitizer --tool memcheck --report-api-errors no --error-exitcode $MEMCHECK_RC ./mat-add)
else
  limit=60
  cmd=(./mat-add)
fi
size="${*// / x }"
timeout $limit "${cmd[@]}" "$@"
rc=$?
case $rc in
  0)   exit 0 ;;
  1)   msg="Wrong results; the log lists the first mismatched elements" ;;
  124) msg="Timed out after $limit s" ;;
  255) msg="CUDA error; the log shows the message and the line. An error inside the kernel is reported at the cudaDeviceSynchronize() after the launch: an illegal memory access, or 'the launch timed out' if the kernel hangs or runs too long" ;;
  $MEMCHECK_RC) msg="Invalid memory access; the compute-sanitizer log shows the kernel, thread and address. Check your bounds checks" ;;
  *)   msg="Crashed with exit code $rc" ;;
esac
# Start on a new line: the program may have died mid-line
echo
echo "::error title=mat-add $size failed::$msg"
exit $rc
